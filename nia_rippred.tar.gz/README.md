# SCINet

[comment]: <> (![pytorch]&#40;https://img.shields.io/badge/-PyTorch-%23EE4C2C?logo=PyTorch&labelColor=lightgrey&#41;)

[comment]: <> ([![cure]&#40;https://img.shields.io/badge/-CURE_Lab-%23B31B1B&#41;]&#40;http://cure-lab.github.io/&#41;)

[comment]: <> (This codes are revised from the following paper : original PyTorch implementation of the following work: [Time Series is a Special Sequence: Forecasting with Sample Convolution and Interaction]&#40;https://arxiv.org/pdf/2106.09305.pdf&#41;. If you find this repository useful for your work, please consider citing it as follows:)

[comment]: <> (```)

[comment]: <> (@article{liu2021SCINet,)

[comment]: <> (  title={Time Series is a Special Sequence: Forecasting with Sample Convolution and Interaction},)

[comment]: <> (  author={Liu, Minhao and Zeng, Ailing and Xu, Zhijian and Lai, Qiuxia and Xu, Qiang},)

[comment]: <> (  journal={arXiv preprint arXiv:2106.09305},)

[comment]: <> (  year={2021})

[comment]: <> (})

[comment]: <> (```)

[comment]: <> (## Updates)

[comment]: <> ([2021-09-17] SCINet v1.0 is released)

[comment]: <> ([2021-11-10] Added Reversible Instance Normalization&#40;RevIN&#41; [[1]&#40;##References&#41;] support!)

[comment]: <> (## Features)

[comment]: <> (- [x] Support **11** popular time-series forecasting datasets.  )

[comment]: <> (![traffic]&#40;https://img.shields.io/badge/🚅-Traffic-yellow&#41;)

[comment]: <> (![electric]&#40;https://img.shields.io/badge/%F0%9F%92%A1-Electricity-yellow&#41;)

[comment]: <> (![Solar Energy]&#40;https://img.shields.io/badge/%F0%9F%94%86-Solar%20Energy-yellow&#41;)

[comment]: <> (![finance]&#40;https://img.shields.io/badge/💵-Finance-yellow&#41;)

[comment]: <> (- [x] Provide all training logs.)

[comment]: <> (- [x] Support RevIN to handle datasets with a large train-test sample distribution gap. To activate, simply add ```--RIN True``` to the command line. [**Read more**]&#40;./docs/RevIN.md&#41;)

## SCINet License
This project is released under the [Apache 2.0 license](LICENSE).


## Get started

### SCINet model
d


### Requirements

Install the required package first:

```
cd SCINet
conda create -n scinet python=3.8
conda activate scinet
pip install -r requirements.txt
```

### Dataset preparation
We conduct the experiments on NIA rip current time-series datasets

The data directory structure is shown as follows. 
```
datasets/
└── NIA/
    └── obs_qc_100p
        ├── DC-total.csv
        ├── HD-total.csv
        ├── JM-total.csv
        ├── NS-total.csv
        └── SJ-total.csv
```

### how to run
```
python run_NIA.py --train_epochs 200 --batch_size 32 --patience 30 --lr 1e-3 --devices 0
```